module.exports = {


  friendlyName: 'Nations',


  description: 'Find nations.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    return jsonData.nations;

  }


};
