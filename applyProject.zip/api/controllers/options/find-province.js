module.exports = {


  friendlyName: 'Province',


  description: 'Find Province.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    return jsonData.province;

  }


};
