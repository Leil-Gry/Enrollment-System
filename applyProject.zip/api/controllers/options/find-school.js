module.exports = {


  friendlyName: 'Find',


  description: 'Find school.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    return jsonData.schools;

  }


};
