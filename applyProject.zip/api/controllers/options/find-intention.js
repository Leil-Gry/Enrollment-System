module.exports = {


  friendlyName: 'Intention',


  description: 'Find intention.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    return jsonData.intention;

  }


};
