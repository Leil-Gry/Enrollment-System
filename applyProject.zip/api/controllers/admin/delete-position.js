module.exports = {


  friendlyName: 'delete Position',


  description: 'delete Position.',

  inputs: {

  },

  exits: {

  },

  fn: async function () {

  }

};
