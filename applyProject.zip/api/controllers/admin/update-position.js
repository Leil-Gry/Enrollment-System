module.exports = {


  friendlyName: 'update Position',


  description: 'update Position.',

  inputs: {

  },

  exits: {


  },

  fn: async function () {

  }

};
