module.exports = {


  friendlyName: 'View distribution',


  description: 'Display "distribution" page.',


  exits: {

    success: {
      viewTemplatePath: 'pages/admin/distribution',
    },


  },


  fn: async function () {

    return {};

  }


};
