'use strict';

module.exports = {
  services: {
    mailer: {
      sendcloud: {
        auth: {
          api_user: 'notice.zjgqt.org',
          api_key: 'pLsLbbWAhwKtIrRk'
        }
      }
    }
  }
};
