'use strict';

module.exports = {
  services: {
    mailer: {
      sendcloud: {
        auth: {
          api_user: 'zjlxjhxm_test_oQW3iS', // 'notice.zjstudent.com',
          api_key: 'jpCD23sc4jcQsEiB'
        }
      }
    }
  }
};
