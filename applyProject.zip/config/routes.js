/**
 * Route Mappings
 * (sails.config.routes)
 *
 * Your routes tell Sails what to do each time it receives a request.
 *
 * For more information on configuring custom routes, check out:
 * https://sailsjs.com/anatomy/config/routes-js
 */

module.exports.routes = {

  //  ╦ ╦╔═╗╔╗ ╔═╗╔═╗╔═╗╔═╗╔═╗
  //  ║║║║╣ ╠╩╗╠═╝╠═╣║ ╦║╣ ╚═╗
  //  ╚╩╝╚═╝╚═╝╩  ╩ ╩╚═╝╚═╝╚═╝
  'GET /':                   { action: 'view-homepage-or-redirect' },
  'GET /welcome/:unused?':   { action: 'dashboard/view-welcome' },

  'GET /signup':             { action: 'entrance/view-signup' },
  'GET /email/confirm':      { action: 'entrance/confirm-email' },
  'GET /email/confirmed':    { action: 'entrance/view-confirmed-email' },
  'GET /email/notconfirmed':    { action: 'entrance/view-need-confirm' },

  'GET /login':              { action: 'entrance/view-login' },
  'GET /password/forgot':    { action: 'entrance/view-forgot-password' },
  'GET /password/new':       { action: 'entrance/view-new-password' },

  'GET /account':            { action: 'account/view-account-overview' },
  'GET /account/password':   { action: 'account/view-edit-password' },
  // 'GET /account/profile':    { action: 'account/view-edit-profile' },
  'GET /statistics':          { action: 'admin/view-statistics' },
  'GET /distribution':          { action: 'admin/view-distribution' },

  'GET /user/apply':          { view: 'pages/user/apply' },
  'GET /admin/dashboard':          { view: 'pages/admin/dashboard' },
  'GET /school/dashboard':          { view: 'pages/school/dashboard' },



  //  ╔╦╗╦╔═╗╔═╗  ╦═╗╔═╗╔╦╗╦╦═╗╔═╗╔═╗╔╦╗╔═╗   ┬   ╔╦╗╔═╗╦ ╦╔╗╔╦  ╔═╗╔═╗╔╦╗╔═╗
  //  ║║║║╚═╗║    ╠╦╝║╣  ║║║╠╦╝║╣ ║   ║ ╚═╗  ┌┼─   ║║║ ║║║║║║║║  ║ ║╠═╣ ║║╚═╗
  //  ╩ ╩╩╚═╝╚═╝  ╩╚═╚═╝═╩╝╩╩╚═╚═╝╚═╝ ╩ ╚═╝  └┘   ═╩╝╚═╝╚╩╝╝╚╝╩═╝╚═╝╩ ╩═╩╝╚═╝
  '/logout':                  '/api/v1/account/logout',


  //  ╦ ╦╔═╗╔╗ ╦ ╦╔═╗╔═╗╦╔═╔═╗
  //  ║║║║╣ ╠╩╗╠═╣║ ║║ ║╠╩╗╚═╗
  //  ╚╩╝╚═╝╚═╝╩ ╩╚═╝╚═╝╩ ╩╚═╝
  // …


  //  ╔═╗╔═╗╦  ╔═╗╔╗╔╔╦╗╔═╗╔═╗╦╔╗╔╔╦╗╔═╗
  //  ╠═╣╠═╝║  ║╣ ║║║ ║║╠═╝║ ║║║║║ ║ ╚═╗
  //  ╩ ╩╩  ╩  ╚═╝╝╚╝═╩╝╩  ╚═╝╩╝╚╝ ╩ ╚═╝
  // Note that, in this app, these API endpoints may be accessed using the `Cloud.*()` methods
  // from the Parasails library, or by using those method names as the `action` in <ajax-form>.
  '/api/v1/account/logout':                           { action: 'account/logout' },
  'PUT   /api/v1/account/update-password':            { action: 'account/update-password' },
  // 'PUT   /api/v1/account/update-profile':             { action: 'account/update-profile' },
  'PUT   /api/v1/entrance/login':                        { action: 'entrance/login' },
  'POST  /api/v1/entrance/signup':                       { action: 'entrance/signup' },
  'POST  /api/v1/entrance/send-password-recovery-email': { action: 'entrance/send-password-recovery-email' },
  'POST  /api/v1/entrance/update-password-and-login':    { action: 'entrance/update-password-and-login' },

  'GET /api/v1/school': { action: 'options/find-school' },
  'GET /api/v1/nation': { action: 'options/find-nation' },
  'GET /api/v1/province': { action: 'options/find-province' },
  'GET /api/v1/city': { action: 'options/find-city' },
  'GET /api/v1/intention': { action: 'options/find-intention' },

  'GET /api/v1/user/apply': { action: 'user/get-apply' },
  'POST  /api/v1/application/apply': { action: 'application/create-application' },
  'POST /api/v1/application/submit': { action: 'application/submit-application'},
  'POST /api/v1/application/:id/file': { action: 'application/upload-photo' },
  'GET /api/v1/application/:id/download': { action: 'application/download' },

  'GET /api/v1/application': { action: 'application/find-application'},
  'GET /api/v1/application/:id': { action: 'application/find-one-application'},
  'GET /api/v1/admin/application/download':          { action: 'admin/download-application' },
  'POST /api/v1/application/:id': { action: 'school/set-order'},
  'POST /api/v1/school/application/:id/status': { action: 'school/update-school-application-status' },
  'POST /api/v1/admin/application/:id/status': { action: 'admin/update-application-status' },
  'POST /api/v1/admin/excel/upload':          { action: 'admin/upload-excel' },
  'GET /api/v1/admin/stats':          { action: 'admin/get-stats' },
  'GET /api/v1/admin/position':          { action: 'admin/get-position-list' },
  'DELETE /api/v1/admin/position/delete':          { action: 'admin/delete-position' },
  'PUT /api/v1/admin/position/update':          { action: 'admin/update-position' },

};
