parasails.registerPage('distribution', {
  data: {
    stats:[],
  },

  beforeMount: async function() {

  },

  methods: {
  }
});
